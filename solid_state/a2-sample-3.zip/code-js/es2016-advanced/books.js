var books=[
    {title:'Harry Potter Part 1',author:'J.K.Rowlings', price:160},
    {title:'Harry Potter Part 2',author:'J.K.Rowlings', price:260},
    {title:'Harry Potter Part 3',author:'J.K.Rowlings', price:360},
    {title:'Harry Potter Part 4',author:'J.K.Rowlings', price:400},
    {title:'Harry Potter Part 5',author:'J.K.Rowlings', price:440},
    {title:'Harry Potter Part 6',author:'J.K.Rowlings', price:460},
    {title:'Harry Potter Part 7',author:'J.K.Rowlings', price:480},
    {title:'Shiva Trilogy Part 1',author:'Amish', price:260},
    {title:'Shiva Trilogy Part 2',author:'Amish', price:220},
    {title:'Shiva Trilogy Part 3',author:'Amish', price:410},

];